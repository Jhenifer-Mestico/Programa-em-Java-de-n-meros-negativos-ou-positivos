/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package valoresreais;

/**
 *
 * @author Jhenifer
 */
import javax.swing.*;
public class ValoresReais {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i, n, pos = 0, neg = 0;
        float valor, soma;
        
        n = Integer.parseInt(JOptionPane.showInputDialog(null, 
                "Digite a quantidade desejada de valores:",
                "Dado", JOptionPane.INFORMATION_MESSAGE));
        
        soma = 0;
        i = 1;
        
        while (i<=n) {
         valor = Float.parseFloat(JOptionPane.showInputDialog(null, 
                "Digite um valor:",
                "Dado", JOptionPane.INFORMATION_MESSAGE));  
        
        if ( valor >=0){
            pos ++;
        }
        
        else {
            neg ++;
        }
        }
        
        i = 1 + 1;
        
        JOptionPane.showMessageDialog(null, "A quantidade de números positivos será: " + pos / n, "Resultado",
                JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, " A quantidade de números negativos será: " + neg / n, "Resultado",
                JOptionPane.INFORMATION_MESSAGE);
    }
    
}
